// src/shared/clipper-pairing.ts
function fromBase64Url(s) {
  return atob(s.replace(/-/g, "+").replace(/_/g, "/"));
}
function decodePairingCode(code) {
  try {
    const parsed = JSON.parse(fromBase64Url(code.trim()));
    if (parsed.v !== 1) return null;
    if (typeof parsed.port !== "number" || !Number.isInteger(parsed.port)) return null;
    if (typeof parsed.secret !== "string" || parsed.secret === "") return null;
    return { v: 1, port: parsed.port, secret: parsed.secret };
  } catch {
    return null;
  }
}

// clipper/src/pairing-store.ts
var KEY = "pairing";
async function loadPairing() {
  const got = await chrome.storage.local.get(KEY);
  const p = got[KEY];
  if (p && typeof p.port === "number" && typeof p.secret === "string") {
    return { v: 1, port: p.port, secret: p.secret };
  }
  return null;
}
async function savePairingCode(code) {
  const decoded = decodePairingCode(code);
  if (!decoded) return null;
  await chrome.storage.local.set({ [KEY]: decoded });
  return decoded;
}
async function clearPairing() {
  await chrome.storage.local.remove(KEY);
}

// clipper/src/ingest.ts
var SECRET_HEADER = "x-minerva-clipper-secret";
function endpoint(pairing, path) {
  return `http://127.0.0.1:${pairing.port}${path}`;
}
async function ping(pairing, fetchImpl = fetch) {
  let res;
  try {
    res = await fetchImpl(endpoint(pairing, "/ping"), {
      headers: { [SECRET_HEADER]: pairing.secret }
    });
  } catch {
    return { ok: false, error: "Not reachable" };
  }
  if (res.status === 401) return { ok: false, error: "Secret rejected \u2014 re-pair the extension." };
  if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
  const body = await res.json().catch(() => ({}));
  return { ok: true, projectOpen: body.projectOpen === true };
}

// clipper/src/options.ts
function el(id) {
  const node = document.getElementById(id);
  if (!node) throw new Error(`missing #${id}`);
  return node;
}
var codeInput = el("code");
var statusEl = el("status");
function setStatus(msg) {
  statusEl.textContent = msg;
}
async function refresh() {
  const pairing = await loadPairing();
  setStatus(pairing ? `Paired \u2014 port ${pairing.port}.` : "Not paired.");
}
el("pair").addEventListener("click", () => {
  void (async () => {
    const pairing = await savePairingCode(codeInput.value);
    if (!pairing) {
      setStatus("That doesn\u2019t look like a valid pairing code.");
      return;
    }
    codeInput.value = "";
    setStatus(`Paired \u2014 port ${pairing.port}.`);
  })();
});
el("test").addEventListener("click", () => {
  void (async () => {
    const pairing = await loadPairing();
    if (!pairing) {
      setStatus("Pair first.");
      return;
    }
    const result = await ping(pairing);
    if (!result.ok) setStatus(`Connection failed: ${result.error}`);
    else setStatus(result.projectOpen ? "Connected \u2014 a thoughtbase is open." : "Connected, but no thoughtbase is open.");
  })();
});
el("unpair").addEventListener("click", () => {
  void (async () => {
    await clearPairing();
    setStatus("Unpaired.");
  })();
});
void refresh();
