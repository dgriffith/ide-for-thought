// clipper/src/pairing-store.ts
var KEY = "pairing";
async function loadPairing() {
  const got = await chrome.storage.local.get(KEY);
  const p = got[KEY];
  if (p && typeof p.port === "number" && typeof p.secret === "string") {
    return { v: 1, port: p.port, secret: p.secret };
  }
  return null;
}

// clipper/src/ingest.ts
var SECRET_HEADER = "x-minerva-clipper-secret";
function endpoint(pairing, path) {
  return `http://127.0.0.1:${pairing.port}${path}`;
}
async function sendClip(pairing, payload, fetchImpl = fetch) {
  let res;
  try {
    res = await fetchImpl(endpoint(pairing, "/ingest"), {
      method: "POST",
      headers: { "Content-Type": "application/json", [SECRET_HEADER]: pairing.secret },
      body: JSON.stringify(payload)
    });
  } catch {
    return { ok: false, error: "Minerva isn\u2019t reachable \u2014 is it running with a thoughtbase open?" };
  }
  let body = {};
  try {
    body = await res.json();
  } catch {
  }
  if (!res.ok) {
    const reason = typeof body.error === "string" ? body.error : `HTTP ${res.status}`;
    return { ok: false, error: reason };
  }
  return {
    ok: true,
    sourceId: typeof body.sourceId === "string" ? body.sourceId : void 0,
    duplicate: typeof body.duplicate === "boolean" ? body.duplicate : void 0,
    title: typeof body.title === "string" ? body.title : void 0,
    excerptId: typeof body.excerptId === "string" ? body.excerptId : void 0
  };
}

// clipper/src/payload.ts
function normalizeSelection(raw) {
  const trimmed = raw?.trim();
  return trimmed ? trimmed : void 0;
}

// clipper/src/capture.ts
function capturePage() {
  return {
    url: location.href,
    html: document.documentElement.outerHTML,
    pageTitle: document.title,
    selection: window.getSelection()?.toString() ?? ""
  };
}
async function captureActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return null;
  const [injected] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: capturePage
  });
  const r = injected?.result;
  if (!r?.html) return null;
  return {
    url: r.url,
    html: r.html,
    pageTitle: r.pageTitle,
    selection: normalizeSelection(r.selection)
  };
}

// clipper/src/background.ts
async function flashBadge(text, color) {
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });
  setTimeout(() => {
    void chrome.action.setBadgeText({ text: "" });
  }, 3e3);
}
async function saveCurrentPage() {
  const pairing = await loadPairing();
  if (!pairing) {
    await flashBadge("?", "#888888");
    await chrome.runtime.openOptionsPage();
    return;
  }
  const payload = await captureActiveTab();
  if (!payload) {
    await flashBadge("!", "#cc3333");
    return;
  }
  const result = await sendClip(pairing, payload);
  if (result.ok) {
    await flashBadge("\u2713", "#22aa22");
  } else {
    await flashBadge("!", "#cc3333");
    console.error("[minerva-clipper]", result.error);
  }
}
chrome.commands.onCommand.addListener((command) => {
  if (command === "save-to-minerva") void saveCurrentPage();
});
