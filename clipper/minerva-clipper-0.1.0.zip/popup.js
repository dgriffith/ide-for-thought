// clipper/src/pairing-store.ts
var KEY = "pairing";
async function loadPairing() {
  const got = await chrome.storage.local.get(KEY);
  const p = got[KEY];
  if (p && typeof p.port === "number" && typeof p.secret === "string") {
    return { v: 1, port: p.port, secret: p.secret };
  }
  return null;
}

// clipper/src/ingest.ts
var SECRET_HEADER = "x-minerva-clipper-secret";
function endpoint(pairing, path) {
  return `http://127.0.0.1:${pairing.port}${path}`;
}
async function sendClip(pairing, payload, fetchImpl = fetch) {
  let res;
  try {
    res = await fetchImpl(endpoint(pairing, "/ingest"), {
      method: "POST",
      headers: { "Content-Type": "application/json", [SECRET_HEADER]: pairing.secret },
      body: JSON.stringify(payload)
    });
  } catch {
    return { ok: false, error: "Minerva isn\u2019t reachable \u2014 is it running with a thoughtbase open?" };
  }
  let body = {};
  try {
    body = await res.json();
  } catch {
  }
  if (!res.ok) {
    const reason = typeof body.error === "string" ? body.error : `HTTP ${res.status}`;
    return { ok: false, error: reason };
  }
  return {
    ok: true,
    sourceId: typeof body.sourceId === "string" ? body.sourceId : void 0,
    duplicate: typeof body.duplicate === "boolean" ? body.duplicate : void 0,
    title: typeof body.title === "string" ? body.title : void 0,
    excerptId: typeof body.excerptId === "string" ? body.excerptId : void 0
  };
}
async function preview(pairing, payload, fetchImpl = fetch) {
  let res;
  try {
    res = await fetchImpl(endpoint(pairing, "/preview"), {
      method: "POST",
      headers: { "Content-Type": "application/json", [SECRET_HEADER]: pairing.secret },
      body: JSON.stringify(payload)
    });
  } catch {
    return { ok: false, error: "Minerva isn\u2019t reachable." };
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    return { ok: false, error: typeof body.error === "string" ? body.error : `HTTP ${res.status}` };
  }
  return {
    ok: true,
    sourceId: typeof body.sourceId === "string" ? body.sourceId : void 0,
    method: typeof body.method === "string" ? body.method : void 0,
    title: typeof body.title === "string" ? body.title : void 0
  };
}

// clipper/src/payload.ts
function normalizeSelection(raw) {
  const trimmed = raw?.trim();
  return trimmed ? trimmed : void 0;
}
function parseTags(raw) {
  const seen = /* @__PURE__ */ new Set();
  for (const part of (raw ?? "").split(/[,\s]+/)) {
    const tag = part.replace(/^#+/, "").trim();
    if (tag) seen.add(tag);
  }
  return [...seen];
}

// clipper/src/capture.ts
function capturePage() {
  return {
    url: location.href,
    html: document.documentElement.outerHTML,
    pageTitle: document.title,
    selection: window.getSelection()?.toString() ?? ""
  };
}
async function captureActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return null;
  const [injected] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: capturePage
  });
  const r = injected?.result;
  if (!r?.html) return null;
  return {
    url: r.url,
    html: r.html,
    pageTitle: r.pageTitle,
    selection: normalizeSelection(r.selection)
  };
}

// clipper/src/popup.ts
function el(id) {
  const node = document.getElementById(id);
  if (!node) throw new Error(`missing #${id}`);
  return node;
}
var titleEl = el("title");
var previewEl = el("preview");
var selectionEl = el("selection");
var tagsInput = el("tags");
var noteInput = el("note");
var saveBtn = el("save");
var statusEl = el("status");
function setStatus(msg) {
  statusEl.textContent = msg;
}
var captured = null;
async function init() {
  const pairing = await loadPairing();
  if (!pairing) {
    titleEl.textContent = "Not paired yet.";
    setStatus("");
    saveBtn.textContent = "Pair\u2026";
    saveBtn.disabled = false;
    saveBtn.addEventListener("click", () => {
      void chrome.runtime.openOptionsPage();
    });
    return;
  }
  captured = await captureActiveTab();
  if (!captured) {
    titleEl.textContent = "Can\u2019t read this page.";
    return;
  }
  titleEl.textContent = captured.pageTitle || captured.url;
  selectionEl.textContent = captured.selection ? `Selection will be saved as an excerpt (${captured.selection.length} chars).` : "";
  saveBtn.disabled = false;
  saveBtn.addEventListener("click", () => {
    void save(pairing);
  });
  const p = await preview(pairing, { url: captured.url, html: captured.html });
  if (p.ok) {
    if (p.title) titleEl.textContent = p.title;
    previewEl.textContent = p.sourceId ? `id: ${p.sourceId}` : "";
  } else {
    previewEl.textContent = p.error ?? "";
  }
}
async function save(pairing) {
  if (!captured) return;
  saveBtn.disabled = true;
  setStatus("Saving\u2026");
  const tags = parseTags(tagsInput.value);
  const note = noteInput.value.trim();
  const result = await sendClip(pairing, {
    ...captured,
    tags: tags.length ? tags : void 0,
    note: note || void 0
  });
  if (result.ok) {
    setStatus(result.duplicate ? "Updated \u2713" : "Saved \u2713");
    setTimeout(() => window.close(), 700);
  } else {
    setStatus(result.error ?? "Failed");
    saveBtn.disabled = false;
  }
}
void init();
